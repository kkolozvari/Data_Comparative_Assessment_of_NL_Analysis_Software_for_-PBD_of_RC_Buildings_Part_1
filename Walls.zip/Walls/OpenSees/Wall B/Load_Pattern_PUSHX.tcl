# Load Pattern for performing displacmeent- or force- controlled analysis:
pattern Plain [expr $SequenceNum + 2] Linear {
	# Create the nodal load - command: load nodeID xForce yForce zForce xMoment yMoment zMoment
	load 13 [expr 0.5*$PhX] [expr 0*$PhY] [expr 0*$PhZ] 0 0 0
	load 21 [expr 0.5*$PhX] [expr 0*$PhY] [expr 0*$PhZ] 0 0 0
	load 30 [expr 0.5*$PhX] [expr 0*$PhY] [expr 0*$PhZ] 0 0 0
	load 43 [expr 0.5*$PhX] [expr 0*$PhY] [expr 0*$PhZ] 0 0 0
	load 51 [expr 0.5*$PhX] [expr 0*$PhY] [expr 0*$PhZ] 0 0 0
	load 60 [expr 0.5*$PhX] [expr 0*$PhY] [expr 0*$PhZ] 0 0 0
}
