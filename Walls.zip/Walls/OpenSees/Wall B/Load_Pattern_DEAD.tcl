# Load Pattern for performing displacmeent- or force- controlled analysis:
pattern Plain [expr $SequenceNum + 2] Linear {
	# Create the nodal load - command: load nodeID xForce yForce zForce xMoment yMoment zMoment
	load 29 [expr 0*$PhX] [expr 0*$PhY] [expr -12.64*$PhZ] 0 0 0
	load 30 [expr 0*$PhX] [expr 0*$PhY] [expr -12.64*$PhZ] 0 0 0
	load 59 [expr 0*$PhX] [expr 0*$PhY] [expr -12.64*$PhZ] 0 0 0
	load 60 [expr 0*$PhX] [expr 0*$PhY] [expr -12.64*$PhZ] 0 0 0
}
