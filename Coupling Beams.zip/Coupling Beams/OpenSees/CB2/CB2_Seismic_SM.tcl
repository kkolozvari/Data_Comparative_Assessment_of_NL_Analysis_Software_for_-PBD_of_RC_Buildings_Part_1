# matTest.tcl: SDOF truss to test uniaxial material models
# Units: kip, in
wipe
model BasicBuilder -ndm 2 -ndf 3

set L 88

# Define nodes ------------------------------------------------------------------
node 1 0.0 0.0
node 2 [expr $L/2] 0.0
node 3 [expr $L/2] 0.0
node 4 $L 0.0

# Boundary Conditions
fix 1 1 1 1
fix 4 1 0 1

# (1)X------------(2)X||(3)X-----------(4)X


# Define beam element -------------------------------------------
set fpc 8000; # psi
set fy 70000; # psi
set L 88
set B 16
set D 24
set k 0.11
#set As [expr 6*0.6]; # 6#7 diagonal bars
#set theta 15.7; # degrees

set A [expr $B*$D]
set E [expr 40*pow($fpc,0.5)+1000]
set Iz [expr $k*$B*pow($D,3)/12]

set transfTag 1;
geomTransf Linear $transfTag
# element elasticBeamColumn $eleTag $iNode $jNode $A $E $Iz $transfTag <-mass $massDens> <-cMass>
element elasticBeamColumn 1 1 2 $A $E $Iz $transfTag
element elasticBeamColumn 2 3 4 $A $E $Iz $transfTag

# Shear Spring Material ........................................................
#set FY [expr 2*$As*$fy*sin($theta*3.14/180)/1000]
set FY 226
set FU [expr 1.05*$FY]


#set s1p [expr 0.2*$FY]
#set e1p 0.1
set s1p [expr 0.75*$FY]
set e1p 0.08
set s2p $FY
set e2p 0.2
set s3p $FU
set e3p 3.0
set s4p [expr 0.3*$FY]
set e4p 4.4
set s5p [expr 0.23*$FY]
set e5p 9
set s6p [expr 0.23*$FY]
set e6p 10

set s7p [expr 0.2*$FY]
set e7p 11



set s1n [expr -1*$s1p]
set e1n [expr -1*$e1p]
set s2n [expr -1*$s2p]
set e2n [expr -1*$e2p]
set s3n [expr -1*$s3p]
set e3n [expr -1*$e3p]
set s4n [expr -1*$s4p]
set e4n [expr -1*$e4p]
set s5n [expr -1*$s5p]
set e5n [expr -1*$e5p]
set s6n [expr -1*$s6p]
set e6n [expr -1*$e6p]
set s7n [expr -1*$s7p]
set e7n [expr -1*$e7p]


set pinchX 0.2
set pinchY 0.2
set damage1 0.0
set damage2 0.0
set beta 0.4


#HystereticSM Material
uniaxialMaterial HystereticSM 1 $s1p $e1p $s2p $e2p $s3p $e3p $s4p $e4p $s5p $e5p $s6p $e6p $s7p $e7p $s1n $e1n $s2n $e2n $s3n $e3n $s4n $e4n $s5n $e5n $s6n $e6n $s7n $e7n $pinchX $pinchY $damage1 $damage2 $beta

# Shear spring
equalDOF 2 3 1 3
element zeroLength 10 2 3 -mat 1 -dir 2

# Select displacement history ---------------------------------------------------
set filename "CB2_Seismic_Protocol.txt";  # Filename containing data points
#set filename "Monotonic.txt";  # Filename containing data points

set factor 1.0;	# Factor applied to data values, i.e. max strain
set dt 1.0;		# Increment between data points

pattern Plain 1 "Series -dt $dt -filePath $filename -factor $factor" {
	# Set reference displacement value
	# node dof value
	sp 4 2 1.0
}

# Set recorders -----------------------------------------------------------------
recorder Node -file Disp.out  -node 4 -dof 2 disp;
recorder Node -file Force.out  -node 4 -dof 2 reaction;

system UmfPack
constraints Penalty 1.0e12 1.0e12

source DisplayModel2D.tcl;
source DisplayPlane.tcl;

set viewScale 0.0001;

DisplayModel2D NodeNumbers;
DisplayModel2D DeformedShape $viewScale;


# Set increment in load factor used for integration -----------------------------
# Does not have to be the same as dt used to read in displacement pattern
set dl $dt
integrator LoadControl $dl 1 $dl $dl
test NormDispIncr 1.0e-6 10
algorithm Newton
numberer RCM
analysis Static
analyze 100000
