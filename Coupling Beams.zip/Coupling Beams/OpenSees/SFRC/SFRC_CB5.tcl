# matTest.tcl: SDOF truss to test uniaxial material models
# Units: kip, in
wipe
model BasicBuilder -ndm 2 -ndf 3

set L 66

# Define nodes ------------------------------------------------------------------
node 1 0.0 0.0
node 2 [expr $L/2] 0.0
node 3 [expr $L/2] 0.0
node 4 $L 0.0

# Boundary Conditions
fix 1 1 1 1
fix 4 1 0 1

# (1)X------------(2)X||(3)X-----------(4)X


# Define beam element -------------------------------------------
set fpc 9140; # psi
set fy 70000; # psi
set L 66
set B 6
set D 20
set k 0.231
#set As [expr 6*0.6]; # 6#7 diagonal bars
#set theta 15.7; # degrees

set A [expr $B*$D]
set E [expr 40*pow($fpc,0.5)+1000]
set Iz [expr $k*$B*pow($D,3)/12]

set transfTag 1;
geomTransf Linear $transfTag
# element elasticBeamColumn $eleTag $iNode $jNode $A $E $Iz $transfTag <-mass $massDens> <-cMass>
element elasticBeamColumn 1 1 2 $A $E $Iz $transfTag
element elasticBeamColumn 2 3 4 $A $E $Iz $transfTag

# Shear Spring Material ........................................................
#set FY [expr 2*$As*$fy*sin($theta*3.14/180)/1000]
set FY 106
set FU [expr 1.05*$FY]

set ePf1 [expr 0.75*$FY]
set ePd1 0.2
set ePf2 $FY 
set ePd2 1
set ePf3 $FU
set ePd3 3.9
set ePf4 [expr 0.2*$FY]
set ePd4 6

set rDispP 0.05

set rForceP 0.5

set uForceP 0.02

set gK1 0.50
set gK2 0.45
set gK3 0.40
set gK4 0.35
set gKLim 1.0
set gD1 0.0
set gD2 0.0
set gD3 0.0
set gD4 0.0
set gDLim 0.0
set gF1 0.0
set gF2 0.0
set gF3 0.0
set gF4 0.0
set gFLim 0.0
set gE 10
set dmgType "energy"

# Build spring materials
uniaxialMaterial Pinching4 1 $ePf1 $ePd1 $ePf2 $ePd2 $ePf3 $ePd3 $ePf4 $ePd4 $rDispP $rForceP $uForceP $gK1 $gK2 $gK3 $gK4 $gKLim $gD1 $gD2 $gD3 $gD4 $gDLim $gF1 $gF2 $gF3 $gF4 $gFLim $gE $dmgType

# Shear spring
equalDOF 2 3 1 3
element zeroLength 10 2 3 -mat 1 -dir 2

# Select displacement history ---------------------------------------------------
set filename "SFRC_CB5_Protocol.txt";  # Filename containing data points
#set filename "Monotonic.txt";  # Filename containing data points

set factor 1.0;	# Factor applied to data values, i.e. max strain
set dt 1.0;		# Increment between data points

pattern Plain 1 "Series -dt $dt -filePath $filename -factor $factor" {
	# Set reference displacement value
	# node dof value
	sp 4 2 1.0
}

# Set recorders -----------------------------------------------------------------
recorder Node -file Disp.out  -node 4 -dof 2 disp;
recorder Node -file Force.out  -node 4 -dof 2 reaction;

system UmfPack
constraints Penalty 1.0e12 1.0e12

source DisplayModel2D.tcl;
source DisplayPlane.tcl;

set viewScale 0.0001;

DisplayModel2D NodeNumbers;
DisplayModel2D DeformedShape $viewScale;


# Set increment in load factor used for integration -----------------------------
# Does not have to be the same as dt used to read in displacement pattern
set dl $dt
integrator LoadControl $dl 1 $dl $dl
test NormDispIncr 1.0e-6 10
algorithm Newton
numberer RCM
analysis Static
analyze 100000
